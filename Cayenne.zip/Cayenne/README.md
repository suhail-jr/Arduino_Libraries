# Cayenne Arduino Library

The Cayenne Arduino Library allows Arduino sketches to easily connect an Arduino device to the Cayenne IoT project builder.

To use the library include the appropriate header file, e.g CayenneEthernet.h, according to the board/shield used for Internet connections. Examples of how to use the library are located under the examples folder.